package com.ibm.download.client;
import javax.activation.DataHandler;

import java.io.*;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.soap.MTOMFeature;
import javax.xml.ws.soap.SOAPBinding;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

 
import com.ibm.download.client.FileServer;
 
public class FileClient{
 
	public static void main(String[] args) throws Exception {
 
	URL url = new URL("http://localhost:9099/ws/file?wsdl");
        QName qname = new QName("http://ws.download.ibm.com/", "FileServerImplService");
 
        Service service = Service.create(url, qname);
       FileServer fileServer = service.getPort(FileServer.class);
 
        /************  test download  ***************/
        DataHandler dh = fileServer.downloadFile("test.pdf");
        FileOutputStream outputStream = new FileOutputStream("E:/test.pdf");
		dh.writeTo(outputStream);
		outputStream.flush();
		
 
        
        System.out.println(" Download Successful!");
 
    }
 
}


