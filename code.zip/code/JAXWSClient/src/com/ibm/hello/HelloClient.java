package com.ibm.hello;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.*;
import javax.xml.namespace.QName;

public class HelloClient {
	public static void main(String[] args) {
		// Setting up the server connection
		HelloUserService service = new HelloUserService();
		HelloUser servicePort = service.getHelloUserPort();
		// Calling the web service
		
		System.out.println(servicePort.sayHello(" " +
				"" +
				"Kuntal"));
		

		// Alternatively if you want to specific the URL directly
		try {
			URL url = new URL("http://localhost:8091/wisequotes?wsdl");
			HelloUserService serviceWithUrl = new HelloUserService(url,new QName("http://hello.ibm.com/","HelloUserService"));
			HelloUser servicePortWithUrl = serviceWithUrl.getHelloUserPort();
			// To Enter user name from Console
			System.out.println("Enter your Name: ");
		    InputStreamReader isr = new InputStreamReader(System.in);
		    BufferedReader br = new BufferedReader(isr);
		    String s = br.readLine();
		    
			
			System.out.println(servicePortWithUrl.sayHello(s));
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
