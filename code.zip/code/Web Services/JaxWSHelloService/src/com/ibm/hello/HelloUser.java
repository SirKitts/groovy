package com.ibm.hello;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.xml.ws.Endpoint;

@WebService
public class HelloUser {
	@SOAPBinding(style = Style.RPC)
	public String sayHello(String name) {
		return "Welcome"+ name;
			}

	public static void main(String[] args) {
		HelloUser server = new HelloUser();
		Endpoint endpoint = Endpoint.publish(
				"http://localhost:8091/wisequotes", server);
	}
}
