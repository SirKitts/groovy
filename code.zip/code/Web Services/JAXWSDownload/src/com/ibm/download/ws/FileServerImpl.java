package com.ibm.download.ws;

import java.io.File;
import java.io.File;
import java.io.IOException;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.jws.WebService;

import javax.xml.ws.WebServiceException;
import javax.xml.ws.soap.MTOM;
 
//Service Implementation Bean
@MTOM
@WebService(endpointInterface = "com.ibm.download.ws.FileServer")
public class FileServerImpl implements FileServer{
 
	@Override
	public DataHandler downloadFile(String fileName) {
 
		//Location of File in Web service
		FileDataSource dataSource = new FileDataSource("c:/test/"+fileName);
		 DataHandler fileDataHandler = new DataHandler(dataSource);
		 return fileDataHandler;
	}
}
