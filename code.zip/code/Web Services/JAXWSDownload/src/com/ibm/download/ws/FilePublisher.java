package com.ibm.download.ws;
import javax.xml.ws.Endpoint;
import com.ibm.download.ws.FileServerImpl;
 
//Endpoint publisher
public class FilePublisher{
 
    public static void main(String[] args) {
 
	Endpoint.publish("http://localhost:9899/ws/file", new FileServerImpl());
 
	System.out.println("Server is published!");
 
    }
}